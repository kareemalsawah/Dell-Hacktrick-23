from gym_maze.envs.maze_env import *
from gym_maze.envs.maze_view_2d import MazeView2D
