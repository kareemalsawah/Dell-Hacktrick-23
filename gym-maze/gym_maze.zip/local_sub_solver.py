import sys
import numpy as np
import math
import random
import json
import requests
import copy

from riddle_solvers import *

from gym_maze.envs.maze_manager import MazeManager
from solution import AlgorithmicAgent

agent = AlgorithmicAgent(visualize=True)
agent.graph.graph = {
    (0, 0): {(1, 0), (0, 1)},
    (1, 0): {(2, 0), (0, 0)},
    (0, 1): {(1, 1), (0, 0)},
    (1, 1): {(0, 1), (1, 2)},
    (0, 2): {(0, 3)},
    (1, 2): {(1, 1), (1, 3)},
    (0, 3): {(0, 2), (0, 4)},
    (1, 3): {(1, 2), (1, 4)},
    (0, 4): {(0, 3), (0, 5)},
    (1, 4): {(1, 3), (1, 5)},
    (0, 5): {(0, 4), (0, 6), (1, 5)},
    (1, 5): {(1, 4), (0, 5)},
    (0, 6): {(0, 7), (1, 6), (0, 5)},
    (1, 6): {(2, 6), (1, 7), (0, 6)},
    (0, 7): {(0, 8), (0, 6)},
    (1, 7): {(1, 6), (1, 8), (2, 7)},
    (0, 8): {(0, 7), (1, 8)},
    (1, 8): {(0, 8), (1, 7), (2, 8)},
    (0, 9): {(1, 9)},
    (1, 9): {(2, 9), (0, 9)},
    (2, 0): {(1, 0), (3, 0)},
    (2, 1): {(3, 1), (2, 2)},
    (2, 2): {(3, 2), (2, 1)},
    (2, 3): {(2, 4), (3, 3)},
    (2, 4): {(2, 3), (2, 5)},
    (2, 5): {(2, 4), (2, 6)},
    (2, 6): {(1, 6), (2, 5), (2, 7)},
    (2, 7): {(1, 7), (2, 6), (2, 8)},
    (2, 8): {(1, 8), (2, 7)},
    (2, 9): {(3, 9), (1, 9)},
    (3, 0): {(3, 1), (4, 0), (2, 0)},
    (3, 1): {(3, 2), (2, 1), (3, 0)},
    (3, 2): {(3, 1), (2, 2)},
    (3, 3): {(2, 3), (3, 4)},
    (3, 4): {(3, 3), (3, 5)},
    (3, 5): {(4, 5), (3, 4)},
    (3, 6): {(3, 7), (4, 6)},
    (3, 7): {(3, 8), (4, 7), (3, 6)},
    (3, 8): {(3, 7), (3, 9), (4, 8)},
    (3, 9): {(4, 9), (2, 9), (3, 8)},
    (4, 0): {(4, 1), (3, 0)},
    (4, 1): {(4, 0), (5, 1), (4, 2)},
    (4, 2): {(4, 3), (4, 1), (5, 2)},
    (4, 3): {(5, 3), (4, 4), (4, 2)},
    (4, 4): {(5, 4), (4, 3)},
    (4, 5): {(5, 5), (3, 5)},
    (4, 6): {(4, 7), (5, 6), (3, 6)},
    (4, 7): {(4, 8), (3, 7), (4, 6), (5, 7)},
    (4, 8): {(4, 9), (3, 8), (4, 7), (5, 8)},
    (4, 9): {(5, 9), (3, 9), (4, 8)},
    (5, 0): {(5, 1), (6, 0)},
    (5, 1): {(5, 0), (4, 1), (5, 2)},
    (5, 2): {(5, 3), (6, 2), (5, 1), (4, 2)},
    (5, 3): {(5, 2), (6, 3), (5, 4), (4, 3)},
    (5, 4): {(4, 4), (5, 3), (6, 4)},
    (5, 5): {(4, 5)},
    (5, 6): {(6, 6), (4, 6), (5, 7)},
    (5, 7): {(5, 6), (4, 7), (5, 8)},
    (5, 8): {(5, 9), (6, 8), (5, 7), (4, 8)},
    (5, 9): {(4, 9), (6, 9), (5, 8)},
    (6, 0): {(6, 1), (7, 0), (5, 0)},
    (6, 1): {(6, 2), (7, 1), (6, 0)},
    (6, 2): {(6, 1), (6, 3), (5, 2)},
    (6, 3): {(5, 3), (6, 2), (7, 3)},
    (6, 4): {(7, 4), (5, 4), (6, 5)},
    (6, 5): {(6, 4)},
    (6, 6): {(6, 7), (5, 6)},
    (6, 7): {(6, 6), (6, 8), (7, 7)},
    (6, 8): {(6, 7), (6, 9), (5, 8)},
    (6, 9): {(7, 9), (5, 9), (6, 8)},
    (7, 0): {(7, 1), (8, 0), (6, 0)},
    (7, 1): {(6, 1), (7, 0), (7, 2), (8, 1)},
    (7, 2): {(8, 2), (7, 1), (7, 3)},
    (7, 3): {(6, 3), (7, 2)},
    (7, 4): {(7, 5), (6, 4)},
    (7, 5): {(7, 4), (8, 5)},
    (7, 6): {(7, 7), (8, 6)},
    (7, 7): {(6, 7), (7, 6), (7, 8)},
    (7, 8): {(7, 9), (8, 8), (7, 7)},
    (7, 9): {(6, 9), (7, 8)},
    (8, 0): {(9, 0), (7, 0), (8, 1)},
    (8, 1): {(8, 2), (9, 1), (7, 1), (8, 0)},
    (8, 2): {(8, 3), (9, 2), (7, 2), (8, 1)},
    (8, 3): {(8, 2), (8, 4), (9, 3)},
    (8, 4): {(8, 3), (9, 4)},
    (8, 5): {(7, 5), (8, 6)},
    (8, 6): {(8, 7), (7, 6), (8, 5)},
    (8, 7): {(8, 8), (8, 6)},
    (8, 8): {(8, 7), (7, 8)},
    (8, 9): {(9, 9)},
    (9, 0): {(9, 1), (8, 0)},
    (9, 1): {(9, 0), (9, 2), (8, 1)},
    (9, 2): {(8, 2), (9, 1), (9, 3)},
    (9, 3): {(8, 3), (9, 2), (9, 4)},
    (9, 4): {(9, 5), (8, 4), (9, 3)},
    (9, 5): {(9, 6), (9, 4)},
    (9, 6): {(9, 5), (9, 7)},
    (9, 7): {(9, 6), (9, 8)},
    (9, 8): {(9, 7), (9, 9)},
    (9, 9): {(8, 9), (9, 8)},
}


def select_action(state):
    action, action_index = agent.get_action(state)  # Random action
    return action, action_index


def submission_inference(riddle_solvers):
    obv = manager.reset(agent_id)

    while True:
        # Select an action
        state_0 = obv
        # print(state_0[0])
        action, action_index = select_action(state_0)  # Random action
        print(agent.count)
        # time.sleep(1)
        # print(agent.graph.graph)
        # time.sleep(0.2)

        if action_index == -1:
            print(state_0[0])
            manager.set_done(agent_id)
            print(agent.graph.graph)
            break

        obv, reward, terminated, truncated, info = manager.step(agent_id, action)

        if info["riddle_type"] is not None:
            solution = riddle_solvers[info["riddle_type"]](info["riddle_question"])
            obv, reward, terminated, truncated, info = manager.solve_riddle(
                info["riddle_type"], agent_id, solution
            )


if __name__ == "__main__":

    agent_id = "9"
    riddle_solvers = {
        "cipher": cipher_solver,
        "captcha": captcha_solver,
        "pcap": pcap_solver,
        "server": server_solver,
    }
    sample_maze = np.load("sample_maze2.npy")
    agent_id = "9"  # add your agent id here

    manager = MazeManager()
    manager.init_maze(agent_id, maze_cells=sample_maze)
    env = manager.maze_map[agent_id]
    maze = {}
    states = {}

    maze["maze"] = env.maze_view.maze.maze_cells.tolist()
    maze["rescue_items"] = list(manager.rescue_items_dict.keys())

    MAX_T = 5000
    RENDER_MAZE = not agent.visualize
    submission_inference(riddle_solvers)
